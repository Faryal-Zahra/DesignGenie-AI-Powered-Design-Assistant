window.applyTheme = (theme) => {
    document.body.className = theme;
};
