public class DesignService
{
    public string ImageUrl { get; set; } = "https://ipfs.io/ipfs/QmaQmfvmc9sYhcZCx4CBiE4SK7M64Dge5dZTAwfVkotz2J/image.png";
    public string ImagePrompt { get; set; } = "";
}